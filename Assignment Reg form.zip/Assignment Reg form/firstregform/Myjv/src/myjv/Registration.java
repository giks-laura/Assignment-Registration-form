/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package myjv;

/**
 *
 * @author root_whizz
 */
public class Registration {
 
    public static void main(String[] args) throws Exception
    {
        MyFrame f = new MyFrame();
    }

    
}
